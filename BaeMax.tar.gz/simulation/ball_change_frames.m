% convert coordinate frame of ball for away team
%
% Modified:
%   2/18/2014 - R. Beard
%
function ball_new = ball_change_frames(ball,P)
    ball_new = -ball;
end
